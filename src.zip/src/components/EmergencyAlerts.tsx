import React, { useState, useEffect } from 'react';
import { AlertTriangle, X, Volume2 } from 'lucide-react';

interface Alert {
  id: string;
  type: 'critical' | 'warning' | 'info';
  title: string;
  message: string;
  timestamp: Date;
}

export function EmergencyAlerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);

  useEffect(() => {
    // Simulate receiving emergency alerts
    const mockAlerts: Alert[] = [
      {
        id: '1',
        type: 'critical',
        title: 'EMERGENCY ALERT',
        message: 'Major fire incident reported in downtown area. All units respond immediately.',
        timestamp: new Date()
      }
    ];

    setAlerts(mockAlerts);
  }, []);

  const removeAlert = (id: string) => {
    setAlerts(alerts.filter(alert => alert.id !== id));
  };

  const alertColors = {
    critical: 'bg-red-600 border-red-700',
    warning: 'bg-orange-600 border-orange-700',
    info: 'bg-blue-600 border-blue-700'
  };

  if (alerts.length === 0) return null;

  return (
    <div className="fixed top-16 left-0 right-0 z-40 space-y-2 p-4">
      {alerts.map((alert) => (
        <div
          key={alert.id}
          className={`${alertColors[alert.type]} text-white rounded-lg shadow-lg border-l-4 animate-pulse`}
        >
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-6 w-6" />
                <Volume2 className="h-5 w-5 animate-bounce" />
              </div>
              <div>
                <h3 className="font-bold text-lg">{alert.title}</h3>
                <p className="text-sm opacity-90">{alert.message}</p>
                <p className="text-xs opacity-75 mt-1">
                  {alert.timestamp.toLocaleTimeString()}
                </p>
              </div>
            </div>
            <button
              onClick={() => removeAlert(alert.id)}
              className="text-white hover:text-gray-200 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}