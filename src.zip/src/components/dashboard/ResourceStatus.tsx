import React from 'react';
import { Package, Truck, Users, AlertTriangle } from 'lucide-react';

export function ResourceStatus() {
  const resources = [
    {
      id: 1,
      name: 'Medical Supplies',
      status: 'good',
      percentage: 85,
      icon: Package,
      location: 'Station 1'
    },
    {
      id: 2,
      name: 'Emergency Vehicles',
      status: 'warning',
      percentage: 65,
      icon: Truck,
      location: 'Fleet Garage'
    },
    {
      id: 3,
      name: 'Available Personnel',
      status: 'good',
      percentage: 92,
      icon: Users,
      location: 'All Stations'
    },
    {
      id: 4,
      name: 'Rescue Equipment',
      status: 'critical',
      percentage: 45,
      icon: AlertTriangle,
      location: 'Station 3'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good':
        return 'text-green-600 bg-green-100';
      case 'warning':
        return 'text-orange-600 bg-orange-100';
      case 'critical':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getProgressColor = (status: string) => {
    switch (status) {
      case 'good':
        return 'bg-green-500';
      case 'warning':
        return 'bg-orange-500';
      case 'critical':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-4">
      {resources.map((resource) => {
        const Icon = resource.icon;
        return (
          <div key={resource.id} className="p-4 border border-gray-200 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-lg ${getStatusColor(resource.status)}`}>
                  <Icon className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">{resource.name}</h4>
                  <p className="text-sm text-gray-500">{resource.location}</p>
                </div>
              </div>
              <span className="text-sm font-medium text-gray-900">
                {resource.percentage}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className={`h-2 rounded-full ${getProgressColor(resource.status)}`}
                style={{ width: `${resource.percentage}%` }}
              ></div>
            </div>
          </div>
        );
      })}
    </div>
  );
}