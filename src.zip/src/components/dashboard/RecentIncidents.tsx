import React from 'react';
import { Clock, MapPin, AlertTriangle, Flame, Droplets } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export function RecentIncidents() {
  const incidents = [
    {
      id: 1,
      type: 'Fire',
      location: 'Downtown District',
      severity: 'critical',
      time: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
      icon: Flame,
      responders: 12
    },
    {
      id: 2,
      type: 'Flooding',
      location: 'River Park Area',
      severity: 'warning',
      time: new Date(Date.now() - 1000 * 60 * 45), // 45 minutes ago
      icon: Droplets,
      responders: 8
    },
    {
      id: 3,
      type: 'Accident',
      location: 'Highway 101',
      severity: 'info',
      time: new Date(Date.now() - 1000 * 60 * 90), // 90 minutes ago
      icon: AlertTriangle,
      responders: 4
    }
  ];

  const severityColors = {
    critical: 'border-red-500 bg-red-50',
    warning: 'border-orange-500 bg-orange-50',
    info: 'border-blue-500 bg-blue-50'
  };

  const severityTextColors = {
    critical: 'text-red-700',
    warning: 'text-orange-700',
    info: 'text-blue-700'
  };

  return (
    <div className="space-y-4">
      {incidents.map((incident) => {
        const Icon = incident.icon;
        return (
          <div
            key={incident.id}
            className={`border-l-4 p-4 rounded-r-lg ${severityColors[incident.severity as keyof typeof severityColors]}`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3">
                <div className={`p-2 rounded-lg ${severityTextColors[incident.severity as keyof typeof severityTextColors]} bg-white`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">{incident.type}</h4>
                  <div className="flex items-center text-sm text-gray-600 mt-1">
                    <MapPin className="h-4 w-4 mr-1" />
                    {incident.location}
                  </div>
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <Clock className="h-4 w-4 mr-1" />
                    {formatDistanceToNow(incident.time, { addSuffix: true })}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <span className={`text-sm font-medium ${severityTextColors[incident.severity as keyof typeof severityTextColors]}`}>
                  {incident.severity.charAt(0).toUpperCase() + incident.severity.slice(1)}
                </span>
                <div className="text-sm text-gray-500 mt-1">
                  {incident.responders} responders
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}