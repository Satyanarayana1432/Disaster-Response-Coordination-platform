import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/layout/Navbar';
import { Dashboard } from './pages/Dashboard';
import { Incidents } from './pages/Incidents';
import { Resources } from './pages/Resources';
import { Volunteers } from './pages/Volunteers';
import { Communications } from './pages/Communications';
import { Analytics } from './pages/Analytics';
import { EmergencyAlerts } from './components/EmergencyAlerts';
import { AuthProvider } from './contexts/AuthContext';
import { NotificationProvider } from './contexts/NotificationContext';

function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Navbar />
            <EmergencyAlerts />
            <main className="pt-16">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/incidents" element={<Incidents />} />
                <Route path="/resources" element={<Resources />} />
                <Route path="/volunteers" element={<Volunteers />} />
                <Route path="/communications" element={<Communications />} />
                <Route path="/analytics" element={<Analytics />} />
              </Routes>
            </main>
          </div>
        </Router>
      </NotificationProvider>
    </AuthProvider>
  );
}

export default App;