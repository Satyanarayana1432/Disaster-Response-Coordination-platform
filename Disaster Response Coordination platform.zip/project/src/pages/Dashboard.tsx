import React from 'react';
import { AlertTriangle, Users, MapPin, Clock, TrendingUp, Shield } from 'lucide-react';
import { MetricCard } from '../components/dashboard/MetricCard';
import { IncidentMap } from '../components/dashboard/IncidentMap';
import { RecentIncidents } from '../components/dashboard/RecentIncidents';
import { ResourceStatus } from '../components/dashboard/ResourceStatus';
import { ResponseTimeChart } from '../components/dashboard/ResponseTimeChart';

export function Dashboard() {
  const metrics = [
    {
      title: 'Active Incidents',
      value: '12',
      change: '+3',
      trend: 'up' as const,
      icon: AlertTriangle,
      color: 'red' as const
    },
    {
      title: 'Available Volunteers',
      value: '247',
      change: '+15',
      trend: 'up' as const,
      icon: Users,
      color: 'blue' as const
    },
    {
      title: 'Resource Centers',
      value: '8',
      change: '0',
      trend: 'neutral' as const,
      icon: MapPin,
      color: 'green' as const
    },
    {
      title: 'Avg Response Time',
      value: '12min',
      change: '-2min',
      trend: 'down' as const,
      icon: Clock,
      color: 'orange' as const
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Emergency Response Dashboard
        </h1>
        <p className="text-gray-600">
          Real-time overview of disaster response operations
        </p>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {metrics.map((metric, index) => (
          <MetricCard key={index} {...metric} />
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Map Section */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">
                Incident Map
              </h2>
              <div className="flex items-center space-x-2">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">Critical</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-orange-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">Warning</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">Info</span>
                </div>
              </div>
            </div>
            <IncidentMap />
          </div>
        </div>

        {/* Recent Incidents */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              Recent Incidents
            </h2>
            <RecentIncidents />
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              Resource Status
            </h2>
            <ResourceStatus />
          </div>
        </div>
      </div>

      {/* Response Time Chart */}
      <div className="mt-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Response Time Trends
          </h2>
          <ResponseTimeChart />
        </div>
      </div>
    </div>
  );
}