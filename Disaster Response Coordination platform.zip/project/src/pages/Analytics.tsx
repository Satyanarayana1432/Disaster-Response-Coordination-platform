import React from 'react';
import { BarChart3, TrendingUp, Clock, Users } from 'lucide-react';

export function Analytics() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Analytics & Reporting
        </h1>
        <p className="text-gray-600">
          Performance metrics and insights for emergency response operations
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 bg-blue-100 rounded-lg">
              <BarChart3 className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Total Incidents</h3>
              <p className="text-2xl font-bold text-gray-900">156</p>
              <p className="text-xs text-green-600">+12% this month</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 bg-green-100 rounded-lg">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Resolution Rate</h3>
              <p className="text-2xl font-bold text-gray-900">94%</p>
              <p className="text-xs text-green-600">+3% this month</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 bg-orange-100 rounded-lg">
              <Clock className="h-6 w-6 text-orange-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Avg Response</h3>
              <p className="text-2xl font-bold text-gray-900">8.5min</p>
              <p className="text-xs text-red-600">+0.5min this month</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 bg-purple-100 rounded-lg">
              <Users className="h-6 w-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Active Personnel</h3>
              <p className="text-2xl font-bold text-gray-900">247</p>
              <p className="text-xs text-blue-600">18 volunteers</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Incident Trends
          </h2>
          <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
            <p className="text-gray-500">Chart showing incident trends over time</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            Response Performance
          </h2>
          <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
            <p className="text-gray-500">Performance metrics visualization</p>
          </div>
        </div>
      </div>

      <div className="mt-8 bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          Monthly Report Summary
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <h3 className="text-lg font-semibold text-gray-900">Incidents Resolved</h3>
            <p className="text-3xl font-bold text-green-600">148</p>
            <p className="text-sm text-gray-500">out of 156 total</p>
          </div>
          <div className="text-center">
            <h3 className="text-lg font-semibold text-gray-900">Volunteer Hours</h3>
            <p className="text-3xl font-bold text-blue-600">1,247</p>
            <p className="text-sm text-gray-500">this month</p>
          </div>
          <div className="text-center">
            <h3 className="text-lg font-semibold text-gray-900">Cost Savings</h3>
            <p className="text-3xl font-bold text-purple-600">$47K</p>
            <p className="text-sm text-gray-500">through coordination</p>
          </div>
        </div>
      </div>
    </div>
  );
}