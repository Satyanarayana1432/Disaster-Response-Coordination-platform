import React from 'react';
import { MapPin, Clock, Users, AlertTriangle, Flame, Droplets, Car } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface IncidentListProps {
  searchTerm: string;
}

export function IncidentList({ searchTerm }: IncidentListProps) {
  const incidents = [
    {
      id: 1,
      title: 'Structure Fire',
      location: '123 Main Street, Downtown',
      severity: 'critical',
      status: 'active',
      type: 'Fire',
      responders: 12,
      time: new Date(Date.now() - 1000 * 60 * 15),
      icon: Flame,
      description: 'Multi-story building fire with potential trapped occupants'
    },
    {
      id: 2,
      title: 'Flash Flood Warning',
      location: 'River Park Area',
      severity: 'warning',
      status: 'monitoring',
      type: 'Flood',
      responders: 8,
      time: new Date(Date.now() - 1000 * 60 * 45),
      icon: Droplets,
      description: 'Rising water levels due to heavy rainfall'
    },
    {
      id: 3,
      title: 'Vehicle Accident',
      location: 'Highway 101, Mile Marker 15',
      severity: 'info',
      status: 'resolved',
      type: 'Accident',
      responders: 4,
      time: new Date(Date.now() - 1000 * 60 * 90),
      icon: Car,
      description: 'Multi-vehicle collision, road cleared'
    },
    {
      id: 4,
      title: 'Medical Emergency',
      location: 'City Hospital',
      severity: 'critical',
      status: 'active',
      type: 'Medical',
      responders: 6,
      time: new Date(Date.now() - 1000 * 60 * 5),
      icon: AlertTriangle,
      description: 'Mass casualty incident requiring additional resources'
    }
  ];

  const filteredIncidents = incidents.filter(incident =>
    incident.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    incident.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
    incident.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const severityColors = {
    critical: 'border-l-red-500 bg-red-50',
    warning: 'border-l-orange-500 bg-orange-50',
    info: 'border-l-blue-500 bg-blue-50'
  };

  const statusColors = {
    active: 'bg-red-100 text-red-800',
    monitoring: 'bg-orange-100 text-orange-800',
    resolved: 'bg-green-100 text-green-800'
  };

  return (
    <div className="p-6">
      <div className="space-y-4">
        {filteredIncidents.map((incident) => {
          const Icon = incident.icon;
          return (
            <div
              key={incident.id}
              className={`border-l-4 p-6 rounded-r-lg ${severityColors[incident.severity as keyof typeof severityColors]} hover:shadow-md transition-shadow`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className="p-3 bg-white rounded-lg shadow-sm">
                    <Icon className="h-6 w-6 text-gray-700" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-lg font-semibold text-gray-900">{incident.title}</h3>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusColors[incident.status as keyof typeof statusColors]}`}>
                        {incident.status.charAt(0).toUpperCase() + incident.status.slice(1)}
                      </span>
                    </div>
                    <p className="text-gray-600 mb-3">{incident.description}</p>
                    <div className="flex items-center space-x-6 text-sm text-gray-500">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {incident.location}
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        {formatDistanceToNow(incident.time, { addSuffix: true })}
                      </div>
                      <div className="flex items-center">
                        <Users className="h-4 w-4 mr-1" />
                        {incident.responders} responders
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button className="px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                    View Details
                  </button>
                  <button className="px-4 py-2 text-sm font-medium text-gray-600 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    Update Status
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      {filteredIncidents.length === 0 && (
        <div className="text-center py-12">
          <AlertTriangle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No incidents found</h3>
          <p className="text-gray-500">Try adjusting your search criteria or create a new incident.</p>
        </div>
      )}
    </div>
  );
}