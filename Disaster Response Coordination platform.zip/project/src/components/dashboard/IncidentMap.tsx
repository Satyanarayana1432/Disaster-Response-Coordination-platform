import React, { useEffect, useRef } from 'react';

export function IncidentMap() {
  const mapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // This would integrate with Leaflet for real mapping
    // For now, we'll show a placeholder that looks like a map
  }, []);

  // Mock incident data
  const incidents = [
    { id: 1, lat: 40.7128, lng: -74.0060, severity: 'critical', type: 'Fire' },
    { id: 2, lat: 40.7589, lng: -73.9851, severity: 'warning', type: 'Flood' },
    { id: 3, lat: 40.6892, lng: -74.0445, severity: 'info', type: 'Accident' }
  ];

  return (
    <div className="relative">
      <div 
        ref={mapRef}
        className="h-96 bg-gradient-to-br from-green-100 to-blue-100 rounded-lg relative overflow-hidden"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23d1d5db' fill-opacity='0.3'%3E%3Ccircle cx='30' cy='30' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}
      >
        {/* Mock incident markers */}
        <div className="absolute top-1/4 left-1/3 w-4 h-4 bg-red-500 rounded-full border-2 border-white shadow-lg animate-pulse"></div>
        <div className="absolute top-1/2 right-1/3 w-4 h-4 bg-orange-500 rounded-full border-2 border-white shadow-lg"></div>
        <div className="absolute bottom-1/3 left-1/2 w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg"></div>
        
        {/* Mock streets */}
        <div className="absolute top-0 left-1/4 w-px h-full bg-gray-300 opacity-50"></div>
        <div className="absolute top-0 right-1/4 w-px h-full bg-gray-300 opacity-50"></div>
        <div className="absolute top-1/4 left-0 w-full h-px bg-gray-300 opacity-50"></div>
        <div className="absolute bottom-1/4 left-0 w-full h-px bg-gray-300 opacity-50"></div>
        
        {/* Legend */}
        <div className="absolute bottom-4 left-4 bg-white bg-opacity-90 rounded-lg p-3 shadow-lg">
          <h4 className="text-sm font-semibold mb-2">Live Incidents</h4>
          <div className="space-y-1">
            <div className="flex items-center text-xs">
              <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
              <span>Critical (3)</span>
            </div>
            <div className="flex items-center text-xs">
              <div className="w-3 h-3 bg-orange-500 rounded-full mr-2"></div>
              <span>Warning (5)</span>
            </div>
            <div className="flex items-center text-xs">
              <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
              <span>Info (4)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}