import React from 'react';
import { TrendingDown, TrendingUp, Clock } from 'lucide-react';

export function ResponseTimeChart() {
  const data = [
    { time: '6 AM', responseTime: 8.5 },
    { time: '9 AM', responseTime: 12.2 },
    { time: '12 PM', responseTime: 15.8 },
    { time: '3 PM', responseTime: 11.4 },
    { time: '6 PM', responseTime: 9.7 },
    { time: '9 PM', responseTime: 7.3 },
    { time: '12 AM', responseTime: 6.8 }
  ];

  const averageResponseTime = data.reduce((sum, item) => sum + item.responseTime, 0) / data.length;
  const trend = data[data.length - 1].responseTime < data[0].responseTime ? 'down' : 'up';

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <Clock className="h-5 w-5 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Average Response Time</h3>
            <p className="text-sm text-gray-500">Last 24 hours</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-gray-900">{averageResponseTime.toFixed(1)} min</p>
          <div className="flex items-center text-sm">
            {trend === 'down' ? (
              <TrendingDown className="h-4 w-4 text-green-600 mr-1" />
            ) : (
              <TrendingUp className="h-4 w-4 text-red-600 mr-1" />
            )}
            <span className={trend === 'down' ? 'text-green-600' : 'text-red-600'}>
              {trend === 'down' ? 'Improving' : 'Needs attention'}
            </span>
          </div>
        </div>
      </div>

      <div className="h-64 flex items-end justify-between space-x-2">
        {data.map((item, index) => (
          <div key={index} className="flex-1 flex flex-col items-center">
            <div
              className="w-full bg-blue-500 rounded-t-lg transition-all duration-300 hover:bg-blue-600"
              style={{
                height: `${(item.responseTime / Math.max(...data.map(d => d.responseTime))) * 200}px`,
                minHeight: '20px'
              }}
            ></div>
            <div className="mt-2 text-center">
              <p className="text-xs font-medium text-gray-900">{item.responseTime} min</p>
              <p className="text-xs text-gray-500">{item.time}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 grid grid-cols-3 gap-4 text-center">
        <div>
          <p className="text-sm text-gray-500">Best Time</p>
          <p className="text-lg font-semibold text-green-600">
            {Math.min(...data.map(d => d.responseTime)).toFixed(1)} min
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Average</p>
          <p className="text-lg font-semibold text-blue-600">
            {averageResponseTime.toFixed(1)} min
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Longest</p>
          <p className="text-lg font-semibold text-orange-600">
            {Math.max(...data.map(d => d.responseTime)).toFixed(1)} min
          </p>
        </div>
      </div>
    </div>
  );
}